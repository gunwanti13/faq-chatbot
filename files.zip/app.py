"""FAQ Chatbot - single-file Streamlit app (NLTK + TF-IDF + cosine similarity).
Run:  streamlit run app.py
"""
import string

import nltk
import streamlit as st
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ------------------------------------------------------------------
# FAQ data - edit this list to use your own topic
# ------------------------------------------------------------------
FAQS = [
    ("How can I track my order?", "Go to 'My Orders' and click 'Track'. You will also get a tracking link by email once your order ships."),
    ("What is your return policy?", "You can return most items within 30 days of delivery if they are unused and in original packaging."),
    ("How do I return a product?", "Open 'My Orders', select the item, click 'Return', and choose a pickup time."),
    ("How long does a refund take?", "Refunds are issued within 5-7 business days after we receive your returned item."),
    ("What payment methods do you accept?", "We accept cards, UPI, net banking, wallets, and cash on delivery."),
    ("Is cash on delivery available?", "Yes, cash on delivery is available for orders up to Rs. 10,000 in most pin codes."),
    ("How long does delivery take?", "Standard delivery takes 3-7 business days. Express takes 1-2 business days in select cities."),
    ("How much is the shipping charge?", "Shipping is free for orders above Rs. 499. Otherwise a flat fee of Rs. 40 applies."),
    ("Can I cancel my order?", "Yes. You can cancel before the order ships from 'My Orders' > 'Cancel'."),
    ("How do I change my delivery address?", "You can change the address before the order ships from 'My Orders' > 'Edit Address'."),
    ("How do I reset my password?", "Click 'Forgot Password' on the login page and follow the reset link we email you."),
    ("How do I create an account?", "Click 'Sign Up', enter your name, email and phone number, and set a password."),
    ("Do you offer international shipping?", "Currently we ship only within India."),
    ("How can I contact customer support?", "Email support@example.com or call 1800-000-000, Monday to Saturday, 9 AM to 6 PM."),
    ("My item arrived damaged. What should I do?", "Report it within 48 hours from 'My Orders' > 'Report Issue' with a photo, and we will replace or refund it."),
    ("Do you have a warranty on products?", "Electronics come with a manufacturer warranty of 6 to 12 months."),
    ("How do I apply a coupon code?", "Enter the code in the 'Apply Coupon' box at checkout and click 'Apply'."),
]
THRESHOLD = 0.2

SYNONYMS = {
    "package": "order", "parcel": "order", "shipment": "order",
    "abroad": "international", "overseas": "international",
    "arrive": "delivery long", "arrived": "delivery long",
    "deliver": "delivery", "ship": "shipping", "shipped": "shipping",
    "where": "track", "status": "track",
    "money": "refund", "reimbursement": "refund",
    "login": "account", "signin": "account", "register": "sign up",
    "pay": "payment", "paid": "payment", "upi": "payment upi", "gpay": "payment upi",
    "broken": "damaged", "defective": "damaged",
    "help": "support", "complaint": "support",
    "discount": "coupon", "promo": "coupon",
}

SUGGESTIONS = [
    "Where is my package?",
    "How do I get my money back?",
    "Can I pay with UPI?",
    "Do you ship abroad?",
]


# ------------------------------------------------------------------
# NLP core
# ------------------------------------------------------------------
@st.cache_resource
def load_nlp():
    for pkg in ("punkt", "punkt_tab", "stopwords", "wordnet"):
        nltk.download(pkg, quiet=True)
    stop = set(stopwords.words("english")) - {"where"}
    return stop, WordNetLemmatizer()


STOP_WORDS, LEMMATIZER = load_nlp()


def preprocess(text: str, use_synonyms: bool = False) -> str:
    text = text.lower().translate(str.maketrans("", "", string.punctuation))
    tokens = [LEMMATIZER.lemmatize(t) for t in word_tokenize(text) if t not in STOP_WORDS]
    if use_synonyms:  # synonyms are applied to the user's query only
        tokens = [w for t in tokens for w in SYNONYMS.get(t, t).split()]
    return " ".join(tokens)


@st.cache_resource
def build_index():
    vectorizer = TfidfVectorizer(ngram_range=(1, 2))
    docs = [preprocess(f"{q} {q} {a}") for q, a in FAQS]
    return vectorizer, vectorizer.fit_transform(docs)


VECTORIZER, FAQ_VECTORS = build_index()


def get_answer(query: str):
    """Return (answer, matched_question, score)."""
    q_vec = VECTORIZER.transform([preprocess(query, use_synonyms=True)])
    scores = cosine_similarity(q_vec, FAQ_VECTORS).flatten()
    best = int(scores.argmax())
    if scores[best] < THRESHOLD:
        return ("Sorry, I couldn't find an answer to that. "
                "Please contact support@example.com.", None, float(scores[best]))
    return FAQS[best][1], FAQS[best][0], float(scores[best])


# ------------------------------------------------------------------
# Streamlit UI
# ------------------------------------------------------------------
st.set_page_config(page_title="FAQ Chatbot", page_icon="💬")
st.title("💬 FAQ Chatbot")
st.caption("Ask about orders, returns, payments, delivery and your account.")

with st.sidebar:
    st.header("About")
    st.write("Matches your question to the most similar FAQ using NLTK preprocessing, "
             "TF-IDF vectors and cosine similarity.")
    st.write(f"FAQs loaded: **{len(FAQS)}**")
    if st.button("Clear chat"):
        st.session_state.messages = []
        st.rerun()

if "messages" not in st.session_state:
    st.session_state.messages = []

if not st.session_state.messages:
    st.session_state.messages.append(
        {"role": "assistant", "content": "Hi! How can I help you today?"}
    )

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])
        if msg.get("meta"):
            st.caption(msg["meta"])

st.write("Try asking:")
cols = st.columns(len(SUGGESTIONS))
clicked = None
for col, text in zip(cols, SUGGESTIONS):
    if col.button(text, use_container_width=True):
        clicked = text

prompt = st.chat_input("Type your question...") or clicked
if prompt:
    answer, matched, score = get_answer(prompt)
    meta = f"Matched FAQ: {matched} (similarity {score:.2f})" if matched else ""
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.session_state.messages.append({"role": "assistant", "content": answer, "meta": meta})
    st.rerun()
